import {NgModule} from '@angular/core';
import {Routes, RouterModule} from '@angular/router';

// Layouts
import {PersonsComponent} from './components/persons/persons.component';
import {AppComponent} from './app.component';

export const routes: Routes = [
  {
    path: '',
    redirectTo: 'persons',
    pathMatch: 'full',
  },
  {
    path: 'persons',
    component: PersonsComponent,
    data: {
      title: 'Persons'
    },
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {

}
