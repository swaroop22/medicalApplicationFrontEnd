import {Component, OnInit, ViewChild} from '@angular/core';
import {ModalDirective} from 'ngx-bootstrap';
import {PersonsService} from '../../services/persons.service';

@Component({
  selector: 'app-persons',
  templateUrl: './persons.component.html',
  styleUrls: ['./persons.component.scss']
})
export class PersonsComponent implements OnInit {
  @ViewChild('addModal') public addModal: ModalDirective;
  @ViewChild('addressModal') public addressModal: ModalDirective;
  @ViewChild('editModal') public editModal: ModalDirective;
  @ViewChild('deleteModal') public deleteModal: ModalDirective;
  @ViewChild('detailsModal') public detailsModal: ModalDirective;


  public Persons: any = [{'name': 'ramesh', 'lastname': 'pasupuleti'}];
  public isAddUserModal = false;
  public isAddressModal = false;
  public isEditModal = false;
  public isDeleteModal = false;
  public isDetailsModal = false;

  public Person = {};
  public addPersonError = '';

  constructor(private PersonsService: PersonsService) {
    this.getPersons();
  }

  ngOnInit() {
  }

  showAddPerson() {
    this.isAddUserModal = true;
  }

  edit(obj) {
    this.Person = JSON.parse(JSON.stringify(obj));
    this.isEditModal = true;
  }

  details(obj) {
    this.Person = JSON.parse(JSON.stringify(obj));
    this.isDetailsModal = true;
  }

  viewAddress(obj) {
    this.Person = JSON.parse(JSON.stringify(obj));
    this.isAddressModal = true;
  }

  delete(obj) {
    this.Person = JSON.parse(JSON.stringify(obj));
    this.isDeleteModal = true;
  }

  onClose(event) {
    if (event === 'add') {
      this.addModal.hide();
    } else if (event === 'address') {
      this.addressModal.hide();
    } else if (event === 'edit') {
      this.editModal.hide();
    } else if (event === 'delete') {
      this.deleteModal.hide();
    } else if (event === 'details') {
      this.detailsModal.hide();
    }
  }

  onHide(event) {
    if (event === 'add') {
      this.isAddUserModal = false;
    } else if (event === 'address') {
      this.isAddressModal = false;
    } else if (event === 'edit') {
      this.isEditModal = false;
    } else if (event === 'delete') {
      this.isDeleteModal = false;
    } else if (event === 'details') {
      this.isDetailsModal = false;
    }
  }

  addPerson(event) {
    const that = this;
    this.PersonsService.addPerson(event).subscribe(function (resp) {
      that.getPersons();
      that.addModal.hide();
    }, function (error) {
      alert('Person add error ' + event.firstName);
    });
  }

  getPersons() {
    const that = this;
    this.PersonsService.getPersons().subscribe(function (resp) {
      that.Persons = resp;
    }, function (error) {
      alert('Error in getting persons');
    });
  }

  deletePerson(data) {
    const that = this;
    this.PersonsService.deletePerson(data).subscribe(function (resp) {
      that.getPersons();
      that.deleteModal.hide();
    }, function (error) {
      alert('Error in delete person ' + data.firstName);
    });
  }

  editPerson(data) {
    const that = this;
    this.PersonsService.updatePerson(data).subscribe(function (resp) {
      that.getPersons();
      that.editModal.hide();
    }, function (error) {
      alert('Error to update person ' + data.firstName);
    });
  }
}
