import {Injectable} from '@angular/core';
import {Observable} from 'rxjs/Observable';
import {Http} from '@angular/http';

import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';

@Injectable()
export class PersonsService {
  private ApiUrl = 'http://localhost:8092/personController';

  constructor(private http: Http) {
  }

  getPersons(): Observable<any> {
    return this.http.get(this.ApiUrl).map(function (response) {
      return response.json();
    }).catch(function (err) {
      return err;
    });
  }

  addPerson(obj): Observable<any> {
    return this.http.post(this.ApiUrl, obj).map(function (response) {
      return response.json();
    }).catch(function (err) {
      return err;
    });
  }

  updatePerson(obj): Observable<any> {
    return this.http.put(this.ApiUrl + '/' + obj.id, obj).map(function (response) {
      return response.json();
    }).catch(function (err) {
      return err;
    });
  }

  deletePerson(obj): Observable<any> {
    return this.http.delete(this.ApiUrl + '/' + obj.id).map(function (response) {
      return response.json();
    }).catch(function (err) {
      return err;
    });
  }


}
