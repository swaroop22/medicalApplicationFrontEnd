import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {PersonsService} from './persons.service';

@NgModule({
  imports: [
    CommonModule
  ],
  providers: [
    PersonsService
  ],
  declarations: []
})
export class ServicesModule {
}
