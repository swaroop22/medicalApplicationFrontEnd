import {BrowserModule} from '@angular/platform-browser';
import {NgModule} from '@angular/core';

import {AppComponent} from './app.component';
import {PersonsComponent} from './components/persons/persons.component';
import {ModalModule, TooltipModule} from 'ngx-bootstrap';
import {AppRoutingModule} from './app.routing';
import {AddpersonComponent} from './modals/addperson/addperson.component';
import {FormsModule, ReactiveFormsModule} from "@angular/forms";
import {ViewaddressComponent} from './modals/viewaddress/viewaddress.component';
import {EditpersonComponent} from './modals/editperson/editperson.component';
import {ServicesModule} from "./services/services.module";
import { DeletepersonComponent } from './modals/deleteperson/deleteperson.component';
import {HttpModule} from '@angular/http';
import { DetailsComponent } from './modals/details/details.component';

@NgModule({
  declarations: [
    AppComponent,
    PersonsComponent,
    AddpersonComponent,
    ViewaddressComponent,
    EditpersonComponent,
    DeletepersonComponent,
    DetailsComponent
  ],
  imports: [
    BrowserModule,
    TooltipModule.forRoot(),
    ModalModule.forRoot(),
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    ServicesModule,
    HttpModule
  ],
  entryComponents: [
    AddpersonComponent,
    ViewaddressComponent,
    EditpersonComponent,
    DeletepersonComponent,
    DetailsComponent
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule {
}
