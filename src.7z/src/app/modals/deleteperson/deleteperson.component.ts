import {Component, EventEmitter, Input, Output} from '@angular/core';

@Component({
  selector: 'app-deleteperson',
  templateUrl: './deleteperson.component.html',
  styleUrls: ['./deleteperson.component.scss']
})
export class DeletepersonComponent {
  @Output() yes = new EventEmitter();
  @Output() cancel = new EventEmitter();
  @Input() User: any;

  constructor() {
  }


  okay() {
    this.yes.emit(this.User);
  }

  close(event) {
    this.cancel.emit(event);
  }

}
