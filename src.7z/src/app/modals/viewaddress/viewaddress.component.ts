import {Component, EventEmitter, Input, Output} from '@angular/core';

@Component({
  selector: 'app-viewaddress',
  templateUrl: './viewaddress.component.html',
  styleUrls: ['./viewaddress.component.scss']
})
export class ViewaddressComponent {
  @Output() cancel = new EventEmitter();
  @Input() data: any;

  constructor() {}

  close(event) {
    this.cancel.emit(event);
  }
}
