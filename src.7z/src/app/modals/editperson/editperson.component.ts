import {Component, EventEmitter, Input, OnChanges, Output, SimpleChanges} from '@angular/core';

@Component({
  selector: 'app-editperson',
  templateUrl: './editperson.component.html',
  styleUrls: ['./editperson.component.scss']
})
export class EditpersonComponent{
  @Output() yes = new EventEmitter();
  @Output() cancel = new EventEmitter();
  @Input() User: any;
  constructor() {
  }

  okay() {
    this.yes.emit(this.User);
  }

  close(event) {
    this.cancel.emit(event);
  }

  addAddress() {
    this.User.addressList.push(
      {
        address1: '',
        address2: '',
        city: '',
        state: '',
        zipCode: '',
      }
    );
  }

  removeAddress(index) {
    this.User.addressList.splice(index, 1);
  }
}
