import {Component, EventEmitter, Input, Output} from '@angular/core';

@Component({
  selector: 'app-details',
  templateUrl: './details.component.html',
  styleUrls: ['./details.component.scss']
})
export class DetailsComponent {

  @Output() cancel = new EventEmitter();
  @Input() data: any;

  constructor() {}

  close(event) {
    this.cancel.emit(event);
  }

}
