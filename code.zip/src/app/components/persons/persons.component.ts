import {Component, OnInit,ViewChild} from '@angular/core';
import {ModalDirective} from "ngx-bootstrap";

@Component({
  selector: 'app-persons',
  templateUrl: './persons.component.html',
  styleUrls: ['./persons.component.scss']
})
export class PersonsComponent implements OnInit {
  @ViewChild('modal') public modal: ModalDirective;
  public Persons: any = [{"name": "ramesh", "lastname": "pasupuleti"}];
  public isAddUserModal = false;
  public addPersonError = '';

  constructor() {
  }

  ngOnInit() {
  }

  showAddPerson() {
    this.isAddUserModal = true;
  }

  edit(obj) {

  }

  viewAddress(obj) {

  }

  delete(obj) {

  }

  closePersonModal(event){
    this.modal.hide();
  }

  addPersonHandler(event) {
    this.isAddUserModal = false;
  }

  addPerson(event){
    console.log(event);
  }
}
