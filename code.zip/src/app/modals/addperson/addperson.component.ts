import {Component, EventEmitter, Input, OnChanges, Output, SimpleChanges} from '@angular/core';

@Component({
  selector: 'app-addperson',
  templateUrl: './addperson.component.html',
  styleUrls: ['./addperson.component.scss']
})
export class AddpersonComponent implements OnChanges {

  @Output() yes = new EventEmitter();
  @Output() cancel = new EventEmitter();
  @Input() Error: any;

  public Roles = [];
  public User = {
    name: '',
    lastname: '',
    address: [{address: ''}]
  };

  constructor() {

  }

  ngOnChanges(changes: SimpleChanges) {
    if (!changes.Error.currentValue.login) {
      this.initEmptyUser();
    }
  }

  initEmptyUser() {
    const user = {
      name: '',
      lastname: '',
      address: [{address: ''}]
    };
    this.User = JSON.parse(JSON.stringify(user));
  }

  okay() {
    this.yes.emit(this.User);
  }

  close(event) {
    this.cancel.emit(event);
  }

  addAddress() {
    this.User.address.push({'address': ''});
  }

  removeAddress(index) {
    this.User.address.splice(index, 1);
  }
}
